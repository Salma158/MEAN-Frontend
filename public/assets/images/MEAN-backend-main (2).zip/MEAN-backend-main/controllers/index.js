/* eslint-disable linebreak-style */
/* eslint-disable global-require */
module.exports = {
  categoriesController: require('./categories'),
  authorsController: require('./authors'),
};
